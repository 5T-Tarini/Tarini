import sys
import os
import cv2
import numpy as np
import imageio
from moviepy.editor import ImageSequenceClip

def create_3d_animation(images, script):
    frames = []
    for img_path in images:
        img = cv2.imread(img_path)
        height, width, _ = img.shape
        for angle in range(0, 360, 5):  
            M = cv2.getRotationMatrix2D((width//2, height//2), angle, 1)
            rotated = cv2.warpAffine(img, M, (width, height))
            frames.append(rotated)

    output_path = "output/video.mp4"
    clip = ImageSequenceClip([cv2.cvtColor(f, cv2.COLOR_BGR2RGB) for f in frames], fps=30)
    clip.write_videofile(output_path, codec="libx264")

    return output_path

if __name__ == "__main__":
    script = sys.argv[1]
    images = sys.argv[2:]
    output_video = create_3d_animation(images, script)
    print(output_video)
