const express = require("express");
const multer = require("multer");
const { exec } = require("child_process");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());

// Ensure directories exist
if (!fs.existsSync("assets")) fs.mkdirSync("assets");
if (!fs.existsSync("output")) fs.mkdirSync("output");

// File Upload Configuration
const upload = multer({ dest: "assets/" });

app.post("/generate", upload.array("images"), (req, res) => {
    const script = req.body.script;
    const imagePaths = req.files.map(file => path.join(__dirname, file.path));

    exec(`python3 process.py "${script}" ${imagePaths.join(" ")}`, (error, stdout) => {
        if (error) {
            console.error(error);
            return res.json({ success: false, error: error.message });
        }
        res.json({ success: true, videoUrl: "/output/video.mp4" });
    });
});

// Serve output videos
app.use("/output", express.static("output"));

app.listen(5000, () => console.log("✅ Server running on http://localhost:5000"));
